"""Demonstration of CVT-ME-MAP-Elites from Listing 2 on the arm repertoire
problem from Vassiliades 2018."""
# yapf: disable
import matplotlib.pyplot as plt
import numpy as np
from ribs.archives import CVTArchive
from ribs.emitters import EvolutionStrategyEmitter, IsoLineEmitter
from ribs.schedulers import BanditScheduler
from ribs.visualize import cvt_archive_heatmap


def evaluate(solution_batch):
    """The arm repertoire problem from Vassiliades 2018.

    The objective is to make the arm have as little variance between its joint
    angles as possible (which makes the arm curve smoothly), while the two
    measures correspond to the final x-y position of the arm.

    This problem is explored further in our arm repertoire tutorial.

    Args:
        solutions (np.ndarray): A (batch_size, dim) array where each row
            contains the joint angles for the arm. `dim` will always be 10
            in this tutorial.
    Returns:
        objs (np.ndarray): (batch_size,) array of objectives.
        meas (np.ndarray): (batch_size, 2) array of measures.
    """
    objective_batch = -np.std(solution_batch, axis=1)

    # Remap the objective from [-1, 0] to [0, 100]
    objective_batch = (objective_batch + 1.0) * 100.0

    # Create links of length one which match the dimensionality of the
    # solutions.
    link_lengths = np.ones(solution_batch.shape[1])

    # theta_1, theta_1 + theta_2, ...
    cum_theta = np.cumsum(solution_batch, axis=1)
    # l_1 * cos(theta_1), l_2 * cos(theta_1 + theta_2), ...
    x_pos = link_lengths[None] * np.cos(cum_theta)
    # l_1 * sin(theta_1), l_2 * sin(theta_1 + theta_2), ...
    y_pos = link_lengths[None] * np.sin(cum_theta)

    measures_batch = np.concatenate(
        (
            np.sum(x_pos, axis=1, keepdims=True),
            np.sum(y_pos, axis=1, keepdims=True),
        ),
        axis=1,
    )

    return objective_batch, measures_batch


archive = CVTArchive(
    solution_dim=10,
    cells=1000,
    ranges=[(-10, 10), (-10, 10)],
    use_kd_tree=True,  # Our CVTArchive relies on a kD-tree
                       # to efficiently identify the cell
                       # where a solution belongs.
)

emitters = [
    EvolutionStrategyEmitter(
        archive,
        x0=[0.0] * 10,
        # Emitters can also manage bounds on the
        # solution space.
        bounds=[(-np.pi, np.pi)] * 10,
        sigma0=0.1,
        ranker="2imp",
    ) for _ in range(5)
] + [
    IsoLineEmitter(
        archive,
        x0=[0.0] * 10,
        bounds=[(-np.pi, np.pi)] * 10,
        iso_sigma=0.1,
        line_sigma=0.2,
    ) for _ in range(5)
]

scheduler = BanditScheduler(archive, emitters,
                            num_active=5)

# Run standard execution loop for 1000 iterations.
for itr in range(1000):
    solutions = scheduler.ask()
    objectives, measures = evaluate(solutions)
    scheduler.tell(objectives, measures)

cvt_archive_heatmap(archive, plot_centroids=False)
plt.show()
