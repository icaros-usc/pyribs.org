"""Demonstration of CMA-ME from Listing 1 on a simple sphere function."""
# yapf: disable
import matplotlib.pyplot as plt
import numpy as np
from ribs.archives import GridArchive
from ribs.emitters import EvolutionStrategyEmitter
from ribs.schedulers import Scheduler
from ribs.visualize import grid_archive_heatmap


def evaluate(solution_batch):
    """Simple sphere function.

    The objective is the negative sphere function, while the measures are the
    first two coordinates of each solution.

    Args:
        solution_batch (np.ndarray): (batch_size, dim) batch of solutions.
    Returns:
        objective_batch (np.ndarray): (batch_size,) batch of objectives.
        measures_batch (np.ndarray): (batch_size, 2) batch of measures.
    """
    objective_batch = -np.sum(np.square(solution_batch), axis=1)
    measures_batch = solution_batch[:, [0, 1]]
    return objective_batch, measures_batch


archive = GridArchive(
    solution_dim=10,  # 10-dimensional solutions.
    dims=[20, 20],  # The grid is 20x20.
    ranges=[(-1, 1), (-1, 1)],  # Each measure ranges
                                # from -1 to 1.
)

emitters = [
    EvolutionStrategyEmitter(
        archive,
        x0=[0.0] * 10,  # 10-dimensional initial
                        # solution for CMA-ES.
        sigma0=0.1,  # Initial standard deviation / step
                     # size for CMA-ES.
        ranker="2imp",  # Two-stage improvement ranking
                        # from CMA-ME.
    ) for _ in range(15)  # 15 emitters.
]

scheduler = Scheduler(archive, emitters)

# Run standard execution loop for 1000 iterations.
for itr in range(1000):
    solutions = scheduler.ask()
    objectives, measures = evaluate(solutions)
    scheduler.tell(objectives, measures)

grid_archive_heatmap(archive)
plt.show()
