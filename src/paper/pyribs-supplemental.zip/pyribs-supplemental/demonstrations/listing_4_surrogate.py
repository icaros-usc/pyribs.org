"""Demonstration of a surrogate-assisted QD algorithm from Listing 4 on the arm
repertoire domain."""
import matplotlib.pyplot as plt
import numpy as np
from ribs.archives import GridArchive
from ribs.emitters import EvolutionStrategyEmitter
from ribs.schedulers import Scheduler
from ribs.visualize import grid_archive_heatmap
from sklearn.linear_model import LinearRegression


def arm(solution_batch, link_lengths):
    """Returns the objective values and measures for a batch of solutions.

    Args:
        solutions (np.ndarray): A (batch_size, dim) array where each row
            contains the joint angles for the arm. `dim` will always be 12
            in this tutorial.
        link_lengths (np.ndarray): A (dim,) array with the lengths of each
            arm link (this will always be an array of ones in the tutorial).
    Returns:
        objs (np.ndarray): (batch_size,) array of objectives.
        meas (np.ndarray): (batch_size, 2) array of measures.
    """
    objective_batch = -np.std(solution_batch, axis=1)

    # Remap the objective from [-1, 0] to [0, 100]
    objective_batch = (objective_batch + 1.0) * 100.0

    # theta_1, theta_1 + theta_2, ...
    cum_theta = np.cumsum(solution_batch, axis=1)
    # l_1 * cos(theta_1), l_2 * cos(theta_1 + theta_2), ...
    x_pos = link_lengths[None] * np.cos(cum_theta)
    # l_1 * sin(theta_1), l_2 * sin(theta_1 + theta_2), ...
    y_pos = link_lengths[None] * np.sin(cum_theta)

    measures_batch = np.concatenate(
        (
            np.sum(x_pos, axis=1, keepdims=True),
            np.sum(y_pos, axis=1, keepdims=True),
        ),
        axis=1,
    )

    return objective_batch, measures_batch


def train_surrogate(solutions, objectives, measures):
    model = LinearRegression()
    Y = np.concatenate((objectives[None].T, measures), axis=1)
    model.fit(solutions, Y)
    return model


def visualize_heatmap(archive):
    plt.figure(figsize=(8, 6))
    grid_archive_heatmap(archive, vmin=0, vmax=100)
    plt.tight_layout()
    plt.savefig("listing_4_surrogate.png")


if __name__ == '__main__':
    # Degrees of freedom for the arm.
    dof = 12

    # Initialize dataset of evaluated soutions.
    rng = np.random.default_rng(123)
    solution_data = np.array(rng.uniform(-np.pi, np.pi, (100, dof)))
    objective_data, measures_data = arm(solution_data, np.ones(dof))

    # Initialize ground truth archive.
    archive = GridArchive(solution_dim=dof,
                          dims=(100, 100),
                          ranges=[(-dof, dof), (-dof, dof)])

    for itr in range(100):
        # Train a linear regression surrogate model on the dataset.
        model = train_surrogate(solution_data, objective_data, measures_data)

        # Initialize CMA-ME.
        s_archive = GridArchive(solution_dim=dof,
                                dims=(100, 100),
                                ranges=[(-dof, dof), (-dof, dof)])
        s_emitters = [
            EvolutionStrategyEmitter(
                s_archive,
                x0=np.zeros(dof),
                sigma0=0.1,
                ranker="2imp",
                bounds=[(-np.pi, np.pi)] * dof,
                batch_size=30,
            ) for _ in range(15)
        ]
        s_scheduler = Scheduler(s_archive, s_emitters)

        # Inner loop: run CMA-ME on surrogate model.
        for _ in range(100):
            solutions = s_scheduler.ask()
            prediction = model.predict(solutions)
            objectives = prediction[:, 0]
            measures = prediction[:, 1:]
            s_scheduler.tell(objectives, measures)

        # Compute ground truth value for all elites from archive.
        elite_solutions = s_archive.as_pandas().solution_batch()
        true_objectives, true_measures = arm(elite_solutions, np.ones(dof))

        # Update ground truth archive.
        archive.add(elite_solutions, true_objectives, true_measures)

        # Update dataset
        solution_data = np.concatenate((solution_data, elite_solutions))
        objective_data = np.concatenate((objective_data, true_objectives))
        measures_data = np.concatenate((measures_data, true_measures))

    # Visualize the archive.
    visualize_heatmap(archive)
