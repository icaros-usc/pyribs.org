"""Demonstration of CMA-MEGA from Listing 3 on the sphere linear projection
benchmark from Fontaine 2020."""
# yapf: disable
import matplotlib.pyplot as plt
import numpy as np
from ribs.archives import GridArchive
from ribs.emitters import GradientArborescenceEmitter
from ribs.schedulers import Scheduler
from ribs.visualize import grid_archive_heatmap


def evaluate(solution_batch):
    """Sphere linear projection benchmark from Fontaine 2020.

    Adapted from the pyribs CMA-MAE tutorial and sphere example.

    Args:
        solution_batch (np.ndarray): (batch_size, dim) batch of solutions.
    Returns:
        objective_grad_batch (np.ndarray): (batch_size, solution_dim) batch of
            objective gradients.
        measures_batch (np.ndarray): (batch_size, 2) batch of measures.
        grad_batch (np.ndarray): (batch_size, 3, solution_dim) batch of
            objective and measure gradients.
    """
    dim = solution_batch.shape[1]

    # Shift the Sphere function so that the optimal value is at x_i = 2.048.
    sphere_shift = 5.12 * 0.4

    # Normalize the objective to the range [0, 100] where 100 is optimal.
    best_obj = 0.0
    worst_obj = (-5.12 - sphere_shift)**2 * dim
    raw_obj = np.sum(np.square(solution_batch - sphere_shift), axis=1)
    objective_batch = (raw_obj - worst_obj) / (best_obj - worst_obj) * 100

    # Compute gradient of the objective.
    objective_grad_batch = -2 * (solution_batch - sphere_shift)

    # Calculate measures.
    clipped = solution_batch.copy()
    clip_mask = (clipped < -5.12) | (clipped > 5.12)
    clipped[clip_mask] = 5.12 / clipped[clip_mask]
    measures_batch = np.concatenate(
        (
            np.sum(clipped[:, :dim // 2], axis=1, keepdims=True),
            np.sum(clipped[:, dim // 2:], axis=1, keepdims=True),
        ),
        axis=1,
    )

    # Compute gradient of the measures.
    derivatives = np.ones(solution_batch.shape)
    derivatives[clip_mask] = -5.12 / np.square(solution_batch[clip_mask])

    mask_0 = np.concatenate((np.ones(dim // 2), np.zeros(dim - dim // 2)))
    mask_1 = np.concatenate((np.zeros(dim // 2), np.ones(dim - dim // 2)))

    d_measure0 = derivatives * mask_0
    d_measure1 = derivatives * mask_1

    measures_grad_batch = np.stack((d_measure0, d_measure1), axis=1)

    objective_grad_batch = np.expand_dims(objective_grad_batch, axis=1)
    grad_batch = np.concatenate((objective_grad_batch, measures_grad_batch),
                                axis=1)

    return objective_batch, measures_batch, grad_batch


archive = GridArchive(
    solution_dim=1000,  # High-dimensional problem.
    dims=[100, 100],
    ranges=[(-2560, 2560), (-2560, 2560)],
)

emitters = [
    GradientArborescenceEmitter(
        archive,
        x0=[0.0] * 1000,
        sigma0=10.0,  # Initial standard deviation of
                      # the gradient coefficient
                      # distribution.
        lr=1.0,  # Learning rate for gradient ascent of
                 # the solution point.
    )
]

scheduler = Scheduler(archive, emitters)

for itr in range(10000):
    solutions = scheduler.ask_dqd()
    objectives, measures, gradients = evaluate(solutions)
    scheduler.tell_dqd(objectives, measures, gradients)

    solutions = scheduler.ask()
    objectives, measures, _ = evaluate(solutions)
    scheduler.tell(objectives, measures)

grid_archive_heatmap(archive, vmin=0, vmax=100)
plt.show()
