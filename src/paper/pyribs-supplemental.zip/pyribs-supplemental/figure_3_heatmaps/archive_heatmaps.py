"""Generates heatmaps for the figure in the paper."""
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from ribs.archives import CVTArchive, GridArchive, SlidingBoundariesArchive
from ribs.visualize import (cvt_archive_heatmap, grid_archive_heatmap,
                            parallel_axes_plot,
                            sliding_boundaries_archive_heatmap)

EXTENSIONS = ["svg", "png"]

LINEWIDTH = 0.75
mpl.rcParams["font.family"] = "Roboto"
mpl.rcParams["font.weight"] = "bold"
mpl.rcParams["font.size"] = "7"
mpl.rcParams["xtick.major.width"] = LINEWIDTH
mpl.rcParams["xtick.minor.width"] = LINEWIDTH
mpl.rcParams["ytick.major.width"] = LINEWIDTH
mpl.rcParams["ytick.minor.width"] = LINEWIDTH
mpl.rcParams["axes.linewidth"] = LINEWIDTH

### grid_archive_heatmap ###

# Populate the archive with a transformed version of the sphere function.
archive = GridArchive(
    solution_dim=2,
    dims=[15, 15],
    ranges=[(-1, 1), (-1, 1)],
)
x = y = np.linspace(-1, 1, 100)
xxs, yys = np.meshgrid(x, y)
xxs, yys = xxs.flatten(), yys.flatten()
archive.add(
    solution_batch=np.stack((xxs, yys), axis=1),
    objective_batch=-(xxs**2 + yys**2) + 2,
    measures_batch=np.stack((xxs, yys), axis=1),
)

# Plot a heatmap of the archive.
plt.figure(figsize=(1.55, 1.25))
grid_archive_heatmap(
    archive,
    aspect="equal",
    vmin=0.0,
    vmax=2.0,
    pcm_kwargs={"rasterized": True},
    cbar_kwargs={
        "aspect": 10,
        "ticks": [0, 2],
    },
)
plt.xticks([-1, 1])
plt.yticks([-1, 1])
plt.tight_layout(pad=0.1)
for ext in EXTENSIONS:
    plt.savefig(f"grid-archive.{ext}", dpi=300)

### cvt_archive_heatmap ###

# Populate the archive with a transformed version of the sphere function.
archive = CVTArchive(
    solution_dim=2,
    samples=10_000,
    cells=100,
    ranges=[(-1, 1), (-1, 1)],
    seed=42,
)
x = y = np.linspace(-1, 1, 100)
xxs, yys = np.meshgrid(x, y)
xxs, yys = xxs.flatten(), yys.flatten()
archive.add(
    solution_batch=np.stack((xxs, yys), axis=1),
    objective_batch=-(xxs**2 + yys**2) + 2,
    measures_batch=np.stack((xxs, yys), axis=1),
)

# Plot a heatmap of the archive.
plt.figure(figsize=(1.55, 1.25))
cvt_archive_heatmap(
    archive,
    aspect="equal",
    vmin=0.0,
    vmax=2.0,
    cbar_kwargs={
        "aspect": 10,
        "ticks": [0, 2],
    },
    plot_centroids=False,
    ms=0.5,
)
plt.xticks([-1, 1])
plt.yticks([-1, 1])
plt.tight_layout(pad=0.1)
for ext in EXTENSIONS:
    plt.savefig(f"cvt-archive.{ext}", dpi=300)

### sliding_boundaries_archive_heatmap ###

archive = SlidingBoundariesArchive(solution_dim=2,
                                   dims=[10, 10],
                                   ranges=[(-10, 10), (-10, 10)],
                                   seed=42)

# Sample 5000 solutions each from two Gaussian with different center.
rng = np.random.default_rng(10)
solution_batch = np.empty((10000, 2), dtype=np.float64)
# Interweave the Gaussians so we have solutions from both Gaussian in the final
# archive.
solution_batch[0::2] = [0, 5]  # Set some centers to be [0, 5].
solution_batch[1::2] = [5, 0]  # Set other centers to be [5, 0].
solution_batch += rng.standard_normal((10000, 2))  # Add the Gaussian noise.

# Evaluate the solutions, normalizing so that the vmin is at 0 and vmax is at 2.
objective_batch = -(solution_batch[:, 0]**2 + solution_batch[:, 1]**2) / 20 + 2

# Compute the measures.
measures_batch = solution_batch

# Populate the archive with the negative sphere function.
archive.add(
    solution_batch=solution_batch,
    objective_batch=objective_batch,
    measures_batch=measures_batch,
)

# Plot a heatmap of the archive.
plt.figure(figsize=(1.55, 1.25))
sliding_boundaries_archive_heatmap(
    archive,
    ms=10,
    boundary_lw=0.4,
    aspect="equal",
    vmin=0,
    vmax=2,
    cbar_kwargs={
        "aspect": 10,
        "ticks": [0, 2],
    },
)
plt.xlim((-2, 7))
plt.ylim((-2, 7))
plt.xticks([-2, 7])
plt.yticks([-2, 7])
plt.tight_layout(pad=0.1)
for ext in EXTENSIONS:
    plt.savefig(f"sliding-boundaries-archive.{ext}", dpi=300)

### Parallel Axes Plot ###

# Populate the archive with the negative sphere function.
archive = GridArchive(
    solution_dim=3,
    dims=[5, 5, 5, 5],
    ranges=[(-1, 1), (-1, 1), (-1, 1), (-1, 1)],
)
for x in np.linspace(-1, 1, 10):
    for y in np.linspace(0, 1, 10):
        for z in np.linspace(-1, 1, 10):
            archive.add_single(
                solution=np.array([x, y, z]),
                objective=-(x**2 + y**2 + z**2) + 2.0,
                measures=np.array([0.5 * x, x, y, -0.5 * z]),
            )
# Plot a heatmap of the archive.
plt.figure(figsize=(1.55, 1.25))
parallel_axes_plot(
    archive,
    measure_order=[(i, f"$m_{i+1}$") for i in range(4)],
    vmin=0,
    vmax=2,
)
plt.tight_layout(pad=0.1)
for ext in EXTENSIONS:
    plt.savefig(f"parallel-axes-plot.{ext}", dpi=300)
