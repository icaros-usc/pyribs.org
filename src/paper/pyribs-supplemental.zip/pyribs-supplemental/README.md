# Supplemental Material for "pyribs: A Bare-bones Python Library for Quality Diversity Optimization"

The supplemental material contains the following files:

- `figure_3_heatmaps/`: Code for generating the heatmaps shown in Figure 3. Make
  sure you have installed pyribs 0.5.0 (`pip install ribs[visualize]==0.5.0`)
  before running this code.

  - Run the file `archive_heatmaps.py` to generate the output. We have also
    included all outputs from the script in this directory.

- `demonstrations/`: Demonstrations of pyribs shown in section 5 and Appendix A.
  Make sure you have installed pyribs 0.5.0 before running this code. The
  following files are included:

  - `listing_1_cma_me.py`
  - `listing_2_cvt_me_map_elites.py`
  - `listing_3_cma_mega.py`
  - `listing_4_surrogate.py`

  Each may be run directly with Python, e.g., `python listing_1_cma_me.py`. We
  have also included example heatmap outputs from each file, i.e.,

  - `listing_1_cma_me.png`
  - `listing_2_cvt_me_map_elites.png`
  - `listing_3_cma_mega.png`
  - `listing_4_surrogate.png`
